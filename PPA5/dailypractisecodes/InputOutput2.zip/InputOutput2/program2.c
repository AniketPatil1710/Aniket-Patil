#include <stdio.h>

void main() {

	char ch ;

	printf("Enter Alphabet:");
	scanf(" %c",&ch);

	if(ch>='A' && ch<='B')
		printf("Enter character UPPERCASE character\n");

	else if(ch='a' && ch<='z')
		printf("Enter character LOWERCASE character\n");
}
