#include <stdio.h>

void main() {
	
	char ch[20];

	scanf("%7s",ch);//means we are able to store 7 character int str string

	printf("%s\n",ch);

}
