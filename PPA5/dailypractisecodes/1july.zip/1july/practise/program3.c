#include <stdio.h>

void main() {

	int a ;

	scanf("%d", &a);

	if (a%2==0)

		printf("no is even\n");
	else
		printf("no is odd\n");
}
