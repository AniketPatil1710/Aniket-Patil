#include <stdio.h>

void main() {

	if('x'<'X') then;

		printf("ascii value of X is smaller than x\n");




}
