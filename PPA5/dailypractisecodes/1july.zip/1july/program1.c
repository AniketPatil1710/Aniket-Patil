#include <stdio.h>

void main() {
	
	int N ;

	printf("Enter any number:");
	scanf("%d",&N);

	if( N >25 && N <=50 )

		printf("%d is belongs to 25 and 50\n",N) ;
	else 
		printf("%d doesn't belongs to 25 and 50\n", N) ;


}
