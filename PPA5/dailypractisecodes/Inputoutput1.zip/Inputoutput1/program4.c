#include <stdio.h>

void main() {

	int num ;
	int integer;
	float fl;
	char character;
   	double dbl;

	printf("Enter your choice:");
	scanf("%d",&num);

	switch(num)
	{
		case 1:
			printf("Enter integer value:");
			scanf("%d",&integer);
			printf("Entered Integer Value is %d\n",integer);
			break;

		case 2 :
			printf("Enter value:");
			scanf("%f", &fl);
			printf("Entered float Value is %f\n",fl);
			break;

		case 3 :
			printf("Enter character:");
			scanf(" %c", &character);
			printf("Entered character Value is %c\n",character);
			break;

		case 4 :
			printf("Enter double value:");
			scanf("%lf",&dbl);
			printf("Entered string is: %lf\n",dbl);
			break;

	}

		
			

}
