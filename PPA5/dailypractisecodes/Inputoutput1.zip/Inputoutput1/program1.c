#include <stdio.h>
#define PI 3.14
void main() {

	float rad,circumference,area ; 

	printf("Radius of circle:");
	scanf("%f",&rad);
	
	circumference = 2*PI*rad;

	area = PI*rad*rad ;

	printf("Area of that circle:%.2f\n",area);

	printf("Circumference of circle:%.2f\n",circumference);
	


}
