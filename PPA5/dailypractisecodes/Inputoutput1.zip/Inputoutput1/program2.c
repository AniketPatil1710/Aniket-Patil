#include <stdio.h>

void main() {

	int hour ;
	int minute ;
	int total_min;

	printf("Enter Hours:");
	scanf("%d",&hour);
	printf("Enter minutes:");
	scanf("%d",&minute);

	total_min = (60*hour) + (minute) ;

	printf("Total Minutes:%dminute\n",total_min);

}
