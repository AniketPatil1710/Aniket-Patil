#include <stdio.h>

void main() {

	int val1 , val2  ;
	float avg ;

	printf("Input :");

	scanf("%d %d",&val1,&val2);

	avg = (val1+val2)/2 ;

	printf("average of %d & %d is %f\n",val1,val2,avg);


}
