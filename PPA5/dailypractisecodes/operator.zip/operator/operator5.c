
#include <stdio.h>

void main() {

	char a ;
	int ans ;

	printf("choose any charactor from a-z or A-z :",a) ;
	scanf("%c", &a) ;

	ans = ++a + ++a ;
        printf("%d\n", &ans) ;





}

