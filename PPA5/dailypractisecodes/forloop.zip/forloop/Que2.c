#include <stdio.h>

void main(){

	int num ;

	for(num=20 ; num<=40 ; num++)

	{
		if(num%2==1)
			printf("%d ",num);

	}
	printf("\n");
}
