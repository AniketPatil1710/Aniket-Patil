#include <stdio.h>

void main() {

	int num ;
	

	for(num=50 ; num<=70 ; num++)

	{
		if(num%2==0)
			printf("%d  ",num);
	}
	printf("\n");
}

