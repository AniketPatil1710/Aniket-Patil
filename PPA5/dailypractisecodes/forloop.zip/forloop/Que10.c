#include <stdio.h>

void main() {

	int num=65 , a ;

	for(a=1 ; a<=65 ; a++ )

	{
		if(num%a==0)
			printf("%d ",a);
	}
	printf("\n");
}
