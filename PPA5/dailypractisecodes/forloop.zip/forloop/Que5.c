#include <stdio.h>

void main() {

	int ch ;

	for(ch=1; ch<=128 ; ch++)

	{
		printf("%c=%d\n",ch,ch);

	}
	printf("\n");

		
}
