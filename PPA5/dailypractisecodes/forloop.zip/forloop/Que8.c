#include <stdio.h>

void main() {

	int ch;

	for(ch=121 ; ch>=106 ; ch--)
	{
		printf("%c ",ch);
	}
	printf("\n");
}
