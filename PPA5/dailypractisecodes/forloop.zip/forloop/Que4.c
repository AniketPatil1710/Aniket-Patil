#include <stdio.h>

void main() {

	int num ;

	for(num = 1 ; num <=50 ; num++)
	{

		if(50%num==0)
			printf("%d\n",num);
	}
	printf("\n");
}
