#include <stdio.h>

void main() {

	int num ;

	for(num=30 ; num>=15 ; num--)

	{
		if(num%2==0)
			printf("%d ",num);
	}
	printf("\n");
}
