#include <stdio.h>

void main() {

	int num , a , b ;

	printf("Enter Number :");
	scanf("%d",&num);

	for(a=1;;a++)
	{

	      
	       {	       
		b=a*num;
		printf("%d ",b);
	       }

	}
	printf("\n");

	
}


