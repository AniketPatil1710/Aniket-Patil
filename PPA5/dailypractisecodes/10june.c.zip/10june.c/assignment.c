
#include <stdio.h>
void main() {
	int a = 15;
	int b = 19 ;
	int ans = 0;
	ans = a & b ;

	printf("a] %d\n",ans) ;
	
  	int x = 7 ;
        int y = 21 ;
        int ans1 = 0 ;
        ans1 = x | y ;

        printf("b] %d\n",ans1) ;
	
	int A = 65;
        int B = 29 ;
        int ans2 = 0;
        ans2 = A & B ;

        printf("c] %d\n",ans2) ;

	int X = 10;
        int ans3 = 0;
        ans3 = X<<4 ;

        printf("d] %d\n",ans3) ;

	int Y = 53;
        int Z = 19 ;
        int ans4 = 0;
        ans4 = Y & Z ;

        printf("e] %d\n",ans4) ;

	int c = 23;
        int d = 77 ;
        int ans5 = 0;
        ans5 =  c | d ;

        printf("f] %d\n",ans5) ;

	int C = 58 ;
        int ans6 = 0;
        ans6 = C<<3 ;

        printf("g] %d\n",ans6) ;

	int D = 45;
        int E = 33 ;
        int ans7 = 0;
        ans7 = D | E ;

        printf("h] %d\n",ans7) ;

	int s = 95;
        int ans8 = 0;
        ans8 = s<<2 ;

        printf("i] %d\n",ans8) ;

        int p = 18;
        int ans9 = 0;
        ans9 = p<<5 ;

        printf("j] %d\n",ans9) ;








}

