#include <stdio.h>

void main() {

	int a = 5 , b = 3 ;

	switch(a) {

		case 1 :
			printf("one\n");

		case 5 :
			printf("two \n");

		case 'b' :
			printf("three \n");

		case 'a' :
		       printf("Four \n") ;
	  	
		default :
			printf("Default\n");
	}		
}
