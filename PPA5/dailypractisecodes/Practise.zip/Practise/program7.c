 #include <stdio.h>

void main() {

	int a=2 ;

	switch(a) {

		case 'a' :
			printf("PPA ");
			break;

		case 2 :
			printf("Java ");
			break;

		default :
			printf("Core2web ");
			break;
	}
}
// here for switch a is given which have if a value 2 so case 2 will get executed
//
// so ans is Java
