#include <stdio.h>

void main(){

	int a=2 ;

	switch (a) {

		case a:
			printf("PPA ");
			break;

		case 2:
			printf("Java ");
			break;

		default:
			printf("Core2web");
			break;
	}


}
//we can not use variables as case label as it requires constant values

